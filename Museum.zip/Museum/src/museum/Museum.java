package museum;

import java.awt.EventQueue;
import java.awt.GridLayout;
import java.sql.*;
import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import java.awt.Component;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.DefaultMutableTreeNode;
//import javax.swing.border.MatteBorder;
import java.awt.Color;
//import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import java.awt.SystemColor;

public class Museum {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					Museum window = new Museum();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}
	Connection connect = null;
	private JTable table;
	protected DefaultMutableTreeNode node_2;
	private JTextField txtPath;
	private JTextField textStatus;
	private JTextField textConOn;
	private JTextField txtSearch;
	private JTextField textSearchInfo;
	
	/**
	 * Create the application.
	 */
	public Museum() {
		initialize();
		}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//SelectMore selectM = new SelectMore();
		DeleteRow deleteR = new DeleteRow();
		AddBike addB = new AddBike();
		LoginDialog dlg = new LoginDialog();
		AddCar addCar =new AddCar();
		UnDo undo =new UnDo();
		connect = dlg.loginDialog();
		ConnectToDB returnUsr = new ConnectToDB();
		Color menuColour = new Color(198, 166, 120);
		Object [] undoData = new Object[12];
		SearchStr searchS = new SearchStr();
		ExportToCsv toCsv = new ExportToCsv();
		//======== THREADS ===========
		//ThRun thRun = new ThRun();
		//Runnable tR = new ThRun(connect);
		Thread thRun = new Thread(new ThRun(connect));
	
		//String[] nameF = null;
		int f1 = 1;
		int f11 = 1;
		int f12 = 1;
		String conStatus = null;
		//String name1 = null;
		//String setQuery = "select student_id from student where first_name = ?";
		//String setQuery1 = "select student_id from student where last_name = ?";
		//String setQuery2 = "select bike_id, plateB, dateB from bikes";
		//String setQuery3 = "Delete from Bikes where bike_id is 3";
		String queryAll = "select * from Vehicles";
		String queryAllfromRow = "select * from VEHICLES where Vehicle_id = ?";
		String querySelectAll = "select * from Vehicles order by Vehicle_ID";
		String querySelectBikes = "select * from Vehicles  where Veh_Type = 'bike' order by Vehicle_ID";
		String querySelectBikesByBrand = "select * from Vehicles  where Veh_Type = 'bike' order by Veh_model";
		String querySelectBikesByYear = "select * from Vehicles  where Veh_Type = 'bike' order by dateProd";
		String querySelectBikesByValue = "select * from Vehicles  where Veh_Type = 'bike' order by valueV";
		String querySelectBikesByEngine = "select * from Vehicles  where Veh_Type = 'bike' order by cc";
		String querySelectBikesByType = "select * from Vehicles  where Veh_Type = 'bike' order by typeB ";
		
		String querySelectCars = "select * from Vehicles  where Veh_Type = 'car' order by Vehicle_ID";
		String querySelectCarsByBrand = "select * from Vehicles  where Veh_Type = 'car' order by Veh_model";
		String querySelectCarsByYear = "select * from Vehicles  where Veh_Type = 'car' order by dateProd";
		String querySelectCarsByValue = "select * from Vehicles  where Veh_Type = 'car' order by valueV";
		String querySelectCarssByEngine = "select * from Vehicles  where Veh_Type = 'car' order by cc";
		//ResultSet selM;
		//String selM1;
		//addAll(model,connect);
		
		//==================== ADD FRAME ====================
		frame = new JFrame();
		frame.setBackground(SystemColor.controlDkShadow);
		frame.setResizable(false);
		frame.setBounds(100, 100, 1016, 485);
		frame.setTitle("Museum Stock");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(64, 63, 68));
		//added Y/N JOptionPane needs add import java.awt.event.WindowAdapter and import java.awt.event.WindowEvent;
		frame.addWindowListener(new WindowAdapter() {
		      public void windowClosing(WindowEvent we) {
		        int result = JOptionPane.showConfirmDialog(frame,
		            "Do you want to Exit ?", "Exit Confirmation : ",
		            JOptionPane.YES_NO_OPTION);
		        if (result == JOptionPane.YES_OPTION)
		          frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        else if (result == JOptionPane.NO_OPTION)
		          frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		      }
		    });
		frame.getContentPane().setLayout(null);
		
		// ================ ADD BIKE ============== 
		
		JButton btnAddBike = new JButton("Add Bike");
		btnAddBike.setBackground(new Color(176, 196, 222));
		btnAddBike.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent argO) {
				try {
					if(connect == null){
						return;
					}
				}catch(Exception e1){
					System.out.println("Not logged in");
				}
				addB.addBike(connect);
				/*
				try {
					
				thRun.start();
				//thRun.stop();
				return;
				//thRun.interrupt();
					
				}catch(Exception e1) {
					System.out.println("Raczej Tu");
					thRun.interrupt();
					//thRun.stop();
				}
				*/
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				try {
				addAll(model, connect, querySelectAll);
				
		            model.fireTableDataChanged();
		            
		            // two lines set only one line to be selected at the time
					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
					table.setRowSelectionInterval(0, 0);
												
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		
		JLabel lblSearch = new JLabel("Search:");
		lblSearch.setForeground(new Color(211, 211, 211));
		lblSearch.setBounds(12, 370, 51, 17);
		frame.getContentPane().add(lblSearch);
		
		JLabel lblLastSearch = new JLabel("Last search:");
		lblLastSearch.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		lblLastSearch.setBounds(180, 427, 64, 17);
		frame.getContentPane().add(lblLastSearch);
		
		textSearchInfo = new JTextField();
		textSearchInfo.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		textSearchInfo.setBackground(new Color(198,166,120));
		textSearchInfo.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		textSearchInfo.setFont(new Font("Dialog", Font.PLAIN, 11));
		textSearchInfo.setBounds(250, 427, 114, 17);
		frame.getContentPane().add(textSearchInfo);
		textSearchInfo.setColumns(10);
		
		txtSearch = new JTextField();
		txtSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				searchS.searchString(model, connect, txtSearch.getText());
				textSearchInfo.setText(txtSearch.getText());
				txtSearch.setText("");
				
			}
		});
		txtSearch.setBackground(new Color(211, 211, 211));
		txtSearch.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtSearch.setBounds(11, 386, 141, 21);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		textConOn = new JTextField();
		textConOn.setBounds(917, 427, 81, 17);
		textConOn.setBackground(menuColour);
		textConOn.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		frame.getContentPane().add(textConOn);
		textConOn.setColumns(10);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		lblStatus.setBounds(676, 428, 44, 17);
		frame.getContentPane().add(lblStatus);
		
		JLabel lblNewLabel = new JLabel("View:");
		lblNewLabel.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		lblNewLabel.setBounds(11, 427, 32, 17);
		frame.getContentPane().add(lblNewLabel);
		
		txtPath = new JTextField();
		txtPath.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		txtPath.setEditable(false);
		txtPath.setBackground(menuColour);
		txtPath.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		txtPath.setFont(new Font("Dialog", Font.PLAIN, 11));
		txtPath.setText("");
		txtPath.setBounds(47, 427, 125, 17);
		frame.getContentPane().add(txtPath);
		txtPath.setColumns(10);
		
		textStatus = new JTextField();
		textStatus.setText("");
		textStatus.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.foreground"));
		textStatus.setFont(new Font("Dialog", Font.PLAIN, 11));
		textStatus.setEditable(false);
		textStatus.setColumns(10);
		textStatus.setBackground(new Color(198, 166, 120));
		textStatus.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		textStatus.setBounds(724, 427, 193, 17);
		frame.getContentPane().add(textStatus);
		try {
		if(connect == null) {
			textStatus.setText(" User: ----   |   Server: ---.---.---.---   |   ");
		}else {
		textStatus.setText(returnUsr.usrAndIpReturn());
		}
		}catch(Exception e1) {
			JOptionPane.showMessageDialog(null,  "No data to delete ");
			
		}
		
		JMenuBar menuBarBottom = new JMenuBar();
		menuBarBottom.setBackground(menuColour);
		menuBarBottom.setBounds(5, 420, 1010, 32);
		frame.getContentPane().add(menuBarBottom);
		btnAddBike.setBounds(164, 381, 104, 27);
		frame.getContentPane().add(btnAddBike);
		
	
		
		//========== SCROLL PANE wrapping TABLE =================
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(164, 58, 834, 286);
		
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		table.setBackground(new Color(220, 220, 220));
		
		//line below disable table editing!!!
		//table.setEnabled(false);
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Vehicle ID", "Type", "Brand", "Reg Plates", "Prod Year", "Value", "Color", "Fuel", "Engine", "Bike Type", "Dors No", "Seats No"
			}
		));
		//------------------ end ---------------------
		
		//================ TABLE COMB FUEL ==========
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		String[] comboBoxF= { "Diesel", "Electric", "Petrol", "Other" };	
		TableColumn fuelList = table.getColumnModel().getColumn(7);
		
		JComboBox comboBoxFuel = new JComboBox(comboBoxF);
		fuelList.setCellEditor(new DefaultCellEditor(comboBoxFuel));
		comboBoxFuel.setSelectedIndex(3);
		//------------------- end -------------------
		
		//============== TABLE COMBO BIKE TYPE ============
		//DefaultTableModel model = (DefaultTableModel) table.getModel();
		String[] optionsType = { "Caferacer", "Cruiser", "Scooter", "Sport", "Trials", "Tourer", "Other" };	
		TableColumn bikeTyopeList = table.getColumnModel().getColumn(9);
		JComboBox comboBikeType = new JComboBox(optionsType);
		bikeTyopeList.setCellEditor(new DefaultCellEditor(comboBikeType));
		comboBikeType.setSelectedIndex(1);
		//------------------- end -------------------- 
		
		//========== Loading data to table (inserted after initiating table) ============

		
	try{
			addAll(model, connect, querySelectAll);
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setRowSelectionInterval(0, 0);
			txtPath.setText("Museum");
	}catch(Exception e1) {
		//JOptionPane.showMessageDialog(null, "OOOOOOOO Connection not established.\nCheck credentials\nGo to menu and try again.");
			
	}
		//------------ end ----------
		
		//========================== ADD RELOAD BTN ===================
		JButton btnReloadAll = new JButton("Reload");
		btnReloadAll.setBackground(new Color(176, 196, 222));
		btnReloadAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
	
				// calls addAlls method
				try {
					addAll(model, connect, querySelectAll);
					// sets: only one row possible to select at the time 
					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
					table.setRowSelectionInterval(0, 0);
				}catch(Exception e1) {JOptionPane.showMessageDialog(null, "Connection not established.\nCheck credentials\nGo to menu and try again.");
				return;
			}
			}
		});
		btnReloadAll.setBounds(902, 381, 96, 27);
		frame.getContentPane().add(btnReloadAll);
		//-------------------- end -----------------
		
		//================= DELETE RECORD ====================
		JButton btnDelRec = new JButton("Delete Item");
		btnDelRec.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.background"));
		btnDelRec.setBackground(new Color(178, 34, 34));
		btnDelRec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int column = 0;
				int row = 0;
			
					
				
				
				//======================
				DefaultTableModel model = (DefaultTableModel) table.getModel();
					if(table.getSelectedRow() == -1) {
						if(table.getRowCount() == 0) {
							JOptionPane.showMessageDialog(null,  "No data to delete ", "Result", JOptionPane.OK_OPTION);
						}else {
							JOptionPane.showMessageDialog(null,  "Select a row", "Result", JOptionPane.OK_OPTION);
						}
					}else {
						 JPanel panel = new JPanel(new GridLayout(0, 1));
						 int confermed = JOptionPane.showConfirmDialog(null, "Delete?", "DELETE?", JOptionPane.OK_CANCEL_OPTION);
							UIManager.put("OptionPane.okButtonText", "OK");
						if(confermed == JOptionPane.YES_OPTION) {
						// two lines set only one line to be selected at the time
						// table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						// table.setRowSelectionInterval(0, 0);
						try {
						//gets first column(cell) from selected row
						row = table.getSelectedRow();
						//String value = table.getModel().getValueAt(row, column).toString();
						String value = table.getModel().getValueAt(row, 0).toString();
						int val1 = Integer.parseInt(value);
						PreparedStatement pst1 = connect.prepareStatement(queryAllfromRow);
						pst1.setInt(1, val1);
						ResultSet rs1 = pst1.executeQuery();
						while(rs1.next()) {
							
			                for (int i = 0; i < 12; i++)
			                {
			                   undoData[i] = rs1.getString(i+1);
			                }								
	
						}	
						//calling delete method
						deleteR.deleteRow(val1, connect);
						model.removeRow(table.getSelectedRow());
					    table.repaint();
						}catch(Exception e1) {
							JOptionPane.showMessageDialog(null, e1);
						}
					}
					//==============================
			}
		}
			});
		btnDelRec.setBounds(706, 380, 96, 27);
		frame.getContentPane().add(btnDelRec);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 76, 140, 268);
		frame.getContentPane().add(scrollPane_1);
		//----------------- end -----------------
		
		//==================== ADD JTREE =====================
		JTree tree = new JTree();
		scrollPane_1.setViewportView(tree);
		tree.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
			try {	
				if(connect == null){
					return;}
				if(tree.isSelectionEmpty())
					return;
				TreePath tp = tree.getSelectionPath();
				DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)tp.getLastPathComponent();
				String categoryName = dmtn.getUserObject().toString();
				
				if(categoryName == "Museum") {
					txtPath.setText("Museum");
					table.repaint();
					addAll(model, connect, querySelectAll);
					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
					table.setRowSelectionInterval(0, 0);
					
				}else if(categoryName == "Bikes") {
					txtPath.setText("Museum/Bike");
					table.repaint();
					addAll(model, connect, querySelectBikes);
					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
					table.setRowSelectionInterval(0, 0);
					
				}else if(categoryName == "bike: brand") {
						txtPath.setText("Museum/Bike/brand");
						DefaultTableModel model = (DefaultTableModel) table.getModel();
						addAll(model, connect, querySelectBikesByBrand);
						try {
							model.fireTableDataChanged();
				            
				            // two lines set only one line to be selected at the time
							table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
							table.setRowSelectionInterval(0, 0);
														
						}catch(Exception e1) {
							JOptionPane.showMessageDialog(null, e1);
						}
						tree.repaint();
						
					}else if(categoryName == "bike: year"){
						txtPath.setText("Museum/Bike/year");
						table.repaint();
						addAll(model, connect, querySelectBikesByYear);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "bike: value"){
						txtPath.setText("Museum/Bike/value");
						table.repaint();
						addAll(model, connect, querySelectBikesByValue);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "bike: engine"){
						txtPath.setText("Museum/Bike/engine");
						table.repaint();
						addAll(model, connect, querySelectBikesByEngine);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "bike: type"){
						txtPath.setText("Museum/bike/type");
						table.repaint();
						addAll(model, connect, querySelectBikesByType);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "Cars") {
						txtPath.setText("Museum/Cars");
						table.repaint();
						addAll(model, connect, querySelectCars);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "car: brand"){
						txtPath.setText("Museum/Car/brand");
						table.repaint();
						addAll(model, connect, querySelectCarsByBrand);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
								
					}else if(categoryName == "car: year"){
						txtPath.setText("Museum/Car/year");
						table.repaint();
						addAll(model, connect, querySelectCarsByYear);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "car: value") {
						txtPath.setText("Museum/Car/value");
						table.repaint();
						addAll(model, connect, querySelectCarsByValue);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
						
					}else if(categoryName == "car: engine") {
						txtPath.setText("Museum/Car/engine");
						table.repaint();
						addAll(model, connect, querySelectCarssByEngine);
						table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						table.setRowSelectionInterval(0, 0);
					}
					
					tree.clearSelection();
			
			
						
					}catch(Exception e1){
						System.out.println("No connection!");
					}
			}
		});
		
			
		
		tree.setModel(new DefaultTreeModel(
			new DefaultMutableTreeNode("Museum") {
				{
					DefaultMutableTreeNode node_1;
					node_1 = new DefaultMutableTreeNode("Bikes");
						node_1.add(new DefaultMutableTreeNode("bike: brand"));
						node_1.add(new DefaultMutableTreeNode("bike: year"));
						node_1.add(new DefaultMutableTreeNode("bike: value"));
						node_1.add(new DefaultMutableTreeNode("bike: engine"));
						node_1.add(new DefaultMutableTreeNode("bike: type"));
					add(node_1);
					node_1 = new DefaultMutableTreeNode("Cars");
						node_1.add(new DefaultMutableTreeNode("car: brand"));
						node_1.add(new DefaultMutableTreeNode("car: year"));
						node_1.add(new DefaultMutableTreeNode("car: value"));
						node_1.add(new DefaultMutableTreeNode("car: engine"));
					add(node_1);
				}
			}
		));
		
		
		//=================== ADD CAR ====================
		JButton btnAddCar = new JButton("Add Car");
		btnAddCar.setBackground(new Color(176, 196, 222));
		btnAddCar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				addCar.addCar(connect);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				addAll(model, connect, querySelectAll);
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setRowSelectionInterval(0, 0);
				
			}
		});
		btnAddCar.setBounds(280, 381, 104, 27);
		frame.getContentPane().add(btnAddCar);
		//---------- end add car -----------
		
		JLabel lblFilters = new JLabel("Filters");
		lblFilters.setForeground(Color.LIGHT_GRAY);
		lblFilters.setBounds(13, 57, 51, 16);
		frame.getContentPane().add(lblFilters);
		
		//===================== UPDATE ==================
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.background"));
		btnUpdate.setBackground(new Color(70, 130, 180));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//String[] undoTemp = new String[14];
				String firstCol = null;
				int row = 0;
				//======================
				DefaultTableModel model = (DefaultTableModel) table.getModel();
					if(table.getSelectedRow() == -1) {
						if(table.getRowCount() == 0) {
							JOptionPane.showMessageDialog(null,  "No data to delete ", "Result", JOptionPane.OK_OPTION);
						}else {
							JOptionPane.showMessageDialog(null,  "Select a row to delete ", "Result", JOptionPane.OK_OPTION);
						}
					}else {
						// two lines set only one line to be selected at the time
						// table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
						// table.setRowSelectionInterval(0, 0);
						
						//gets first column(cell) from selected row
						row = table.getSelectedRow();
						//getting values from table(selected row)
						String valueT1 = table.getModel().getValueAt(row, 0).toString();
						String valueT2 = table.getModel().getValueAt(row, 1).toString();
						String valueT3 = table.getModel().getValueAt(row, 2).toString();
						String valueT4 = table.getModel().getValueAt(row, 3).toString().toUpperCase();
						String valueT5 = table.getModel().getValueAt(row, 4).toString();
						String valueT6 = table.getModel().getValueAt(row, 5).toString();
						String valueT7 = table.getModel().getValueAt(row, 6).toString();
						String valueT8 = table.getModel().getValueAt(row, 7).toString();
						String valueT9 = table.getModel().getValueAt(row, 8).toString();
						String valueT10 = table.getModel().getValueAt(row, 9).toString();
						String valueT11 = table.getModel().getValueAt(row, 10).toString();
						String valueT12 = table.getModel().getValueAt(row, 11).toString();
						
						
						//converting needed data to Int 
						int f1 =  Integer.parseInt(valueT1);
						int f5 =  Integer.parseInt(valueT5);
						int f6 =  Integer.parseInt(valueT6);
						int f9 =  Integer.parseInt(valueT9);
						//int f11 =  Integer.parseInt(valueT11);
						//int f12 =  Integer.parseInt(valueT12);
					

						//Create query ready for updating
						//String queryUpdate = "INSERT INTO Vehicles VALUES("+f1+",'"+valueT2+"','"+valueT3+"','"+valueT4+"',"+f5+","+f6+",'"+valueT7+"','"+valueT8+"',"+f9+",'"+valueT10+"',"+f11+","+f12+")";
						//String queryUpdateBike = "INSERT INTO Vehicles VALUES("+f1+",'"+valueT2+"','"+valueT3+"','"+valueT4+"',"+f5+","+f6+",'"+valueT7+"','"+valueT8+"',"+f9+",'"+valueT10+"',"+f11+","+f12+")";
						String queryUpdate = "INSERT INTO Vehicles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
																		
						// retreiving data from query for selected row 		 										
						try {
					/*	String queryRow = "select vehicle_id from VEHICLES where Vehicle_id=?";
						PreparedStatement pst = connect.prepareStatement(queryRow);
						pst.setInt(1, f1);
						ResultSet rs = pst.executeQuery();
						while(rs.next()) {
			                   firstCol = rs.getString(1);
							}*/
					//	try {
							
							
							PreparedStatement pst1 = connect.prepareStatement(queryAllfromRow);
							pst1.setInt(1, f1);
							ResultSet rs1 = pst1.executeQuery();
							while(rs1.next()) {
								
				                for (int i = 0; i < 12; i++)
				                {
				                   undoData[i] = rs1.getString(i+1);
				                }								
		
							}
						
						// ======== delete original records from query to give room for updated one
						deleteR.deleteRow(f1, connect);
						
						//======= update db
						
							//String queryUpdate1 = "INSERT INTO Vehicles VALUES(?,?,?,?,?,?,?,?,?,?,null,null)";
						queryUpdate = "INSERT INTO Vehicles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

							PreparedStatement psUp = connect.prepareStatement(queryUpdate);
							
							if(!valueT11.equals("n/a")) {
								psUp.setInt(11, Integer.parseInt(valueT11));
						    	}else {
						    		psUp.setNull(11, java.sql.Types.DOUBLE);
						    	}
						    if(!valueT12.equals("n/a")) {
						    	psUp.setInt(12, Integer.parseInt(valueT12));
							   	}else {
							   		psUp.setNull(12, java.sql.Types.DOUBLE);
							   	}
							
					    	
					    	psUp.setInt(1, f1);
					    	psUp.setString(2, valueT2);
					    	psUp.setString(3, valueT3);  	
							psUp.setString(4, valueT4.toUpperCase());
							psUp.setInt(5, f5);
							psUp.setInt(6, f6);
							psUp.setString(7, valueT7);
							psUp.setString(8, valueT8);
							psUp.setInt(9, f9);
							psUp.setString(10, valueT10.toUpperCase());
							//psUp.setNull(11, java.sql.Types.DOUBLE);
							//psUp.setNull(12, java.sql.Types.DOUBLE);
							//psUp.setInt(11, ff11);
							//psUp.setInt(12, ff12); 

					   psUp.executeUpdate();
					    	psUp.close();
					    	table.repaint();
						}catch(Exception e1) {
							JOptionPane.showMessageDialog(null, e1);
						}
						model.fireTableDataChanged();
					    table.repaint();
					}
			}
		});
		btnUpdate.setBounds(482, 380, 104, 27);
		frame.getContentPane().add(btnUpdate);
		//-------------- end ------------
		
		//================ UNDO =====================
		JButton btnUndo = new JButton("Undo");
		btnUndo.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.background"));
		btnUndo.setBackground(new Color(107, 142, 35));
		btnUndo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
		try {
			
				undo.unDo(connect, undoData);
				model.fireTableDataChanged();
				addAll(model, connect, querySelectAll);
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setRowSelectionInterval(0, 0);
				table.repaint();
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setRowSelectionInterval(0, 0);
			}catch(Exception e1) {JOptionPane.showMessageDialog(null, "Connection not established.\nCheck credentials\nGo to menu and try again.");
			return;
		}
			}
		});
		btnUndo.setBounds(598, 380, 96, 27);
		frame.getContentPane().add(btnUndo);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(new Color(51, 51, 51));
		menuBar.setBackground(new Color(64, 73, 68));
		menuBar.setBounds(5, 0, 1010, 21);
		frame.getContentPane().add(menuBar);
		
		JMenu mnMenu = new JMenu("Menu");
		mnMenu.setForeground(UIManager.getColor("OptionPane.warningDialog.titlePane.background"));
		menuBar.add(mnMenu);
		
		JMenuItem mntmLogIn = new JMenuItem("Log in");
		mntmLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				String conSt;
				connect = dlg.loginDialog();
				addAll(model, connect, querySelectAll);
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setRowSelectionInterval(0, 0);
				txtPath.setText("Museum");
				
					textStatus.setText(returnUsr.usrAndIpReturn());
					if(connect == null){
						conSt = "Not Connected";
						textConOn.setForeground(Color.RED);
						textConOn.setText(conSt);
					}else{
						conSt = "Connected";
						textConOn.setForeground(Color.GREEN);
						textConOn.setText(conSt);
						}
				}catch(Exception e1) {
					
				}
			}
		});
		mnMenu.add(mntmLogIn);
		mntmLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					}
		});
		
		JSeparator separator_1 = new JSeparator();
		mnMenu.add(separator_1);
		
		JMenuItem mntmExport = new JMenuItem("Export (*.csv)");
		mnMenu.add(mntmExport);
		mntmExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
			//Create a file chooser
			JFileChooser fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			
			//...
			//In response to a button click:
			int returnVal = fc.showSaveDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
	            File file = fc.getSelectedFile();
	            //This is where a real application would open the file.
	            toCsv.exportToCsv(connect, file.getAbsolutePath());
	            System.out.println(file.getAbsolutePath());
	            
				}
			}
		});
		
		JSeparator separator = new JSeparator();
		mnMenu.add(separator);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//table.repaint();
				//searchS.searchString(model, connect, "54");
				//searchString(model, connect, "50");
				table.repaint();
				 JPanel panel = new JPanel(new GridLayout(0, 1));
				 int confermed = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "EXIT?", JOptionPane.OK_CANCEL_OPTION);
					UIManager.put("OptionPane.okButtonText", "OK");
				if(confermed == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		mnMenu.add(mntmExit);
		
		JLabel lblNewLabel_1 = new JLabel(new ImageIcon("/home/ra/eclipse-workspace/Museum/lib/dropbar1.jpg"));
		lblNewLabel_1.setBounds(5, 22, 1010, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel(new ImageIcon("/home/ra/eclipse-workspace/Museum/lib/dropbar2.jpg"));
		label.setBounds(5, 367, 1010, 53);
		frame.getContentPane().add(label);
		
		try {
			if(connect == null){
				conStatus = "Not Connected";
				textConOn.setForeground(Color.RED);
				textConOn.setText(conStatus);
			}else{
				conStatus = "Connected";
				textConOn.setForeground(Color.GREEN);
				textConOn.setText(conStatus);
				}
		}catch(Exception e1){
			System.out.println("Not connected!");
		}
	//	textConOn.setText(conStatus);
		//--------------- end -------------
		

	}
	
	//================== METHOD addAll =================
	public static void addAll(DefaultTableModel model, Connection connect, String query) {
		try {
			//String query = "select * from Vehicles order by Vehicle_ID";
			PreparedStatement pst = connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			ResultSetMetaData meta = rs.getMetaData();
			int numberOfColumns = meta.getColumnCount();
			int count = 0;
			model.setRowCount(0);
			while(rs.next()) {
				
				Object [] rowData = new Object[numberOfColumns];
                for (int i = 0; i < rowData.length; ++i)
                {
                    rowData[i] = rs.getObject(i+1);
                    
                    if(rowData[i] == null) {
                    	rowData[i] = "n/a";
                    }else if(rowData[i].equals("p")) {
                    	rowData[i] = "petrol";
                    }else if(rowData[i].equals("d")) {
                    	rowData[i] = "diesel";
                    }
                }
                model.addRow(rowData);
				count++;
							}
	/*		if (count == 1) {
				JOptionPane.showMessageDialog(null, "There is: " + count + " record");
			}else if(count > 1){
				JOptionPane.showMessageDialog(null, "There are: " + count + " records");
			}else {
				JOptionPane.showMessageDialog(null, "URecord does't exixt");
			}
			*/
			model.fireTableDataChanged();
			rs.close();
			pst.close();
		}catch(Exception e1) {
			//JOptionPane.showMessageDialog(null, "zzzzzConnection not established.\nCheck credentials\nGo to menu and try again.");
			return;
		}
	}
}