package museum;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.*;


public class LoginDialog extends JPanel {
	public LoginDialog() {
	}

	//iniciating Connection
	
	Connection connect = null;


	/**
	 * Create the panel.
	 * @return 
	 */
	//@SuppressWarnings("deprecation")
	public Connection loginDialog() {

		
		JTextField field1 = new JTextField("ra");
		
		JTextField field2 = new JTextField("192.168.0.10");
		JTextField field3 = new JTextField("1521");
		JTextField field4 = new JTextField("xe");
		JPasswordField fieldPass = new JPasswordField("or2acle2");
		fieldPass.setEchoChar('\u25CF');
        JPanel panel = new JPanel(new GridLayout(0, 1));
        UIManager.put("OptionPane.okButtonText", "Login");
        panel.add(new JLabel("User:"));
        panel.add(field1);
        panel.add(new JLabel("Pass:"));
        panel.add(fieldPass);
        
        panel.add(new JLabel("IP address:"));
        panel.add(field2);
        panel.add(new JLabel("Port:"));
        panel.add(field3);
        panel.add(new JLabel("SID:"));
        panel.add(field4);
        try {
 
        int option = JOptionPane.showConfirmDialog(null, panel, "Log In", JOptionPane.OK_CANCEL_OPTION);
        try {
        if(option == JOptionPane.CANCEL_OPTION) {
        	connect = null;
        	//System.exit(0);
        	return null;
        }
        }catch(Exception e) {
        	
        }
        UIManager.put("OptionPane.okButtonText", "OK");
		//UIManager.put("OptionPane.minimumSize",new Dimension(500,500));
		connect = ConnectToDB.dbConnector(field1.getText(), new String(fieldPass.getPassword()), field2.getText(), field3.getText(), field4.getText());
        
      
        }catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
		
	return connect;
	}
}
