package museum;

import java.sql.Connection;

public class ThRun implements Runnable{
	Connection connect = null;
	AddBike bike = new AddBike();
	boolean run = true;
	
	public ThRun(Connection conn) {
		this.connect = conn;
	}
	@Override
	public void run() {
		
		// TODO Auto-generated method stub
		
		try {
		while(true) {
			bike.addBike(connect);
		return;
		}
		}catch(Exception e){
			System.out.println("Tu jestes!");
		
			run = false;
		
		}
		
		return;
		
		
	}

}
