package museum;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.util.Arrays;

import javax.swing.JOptionPane;
//import javax.swing.table.DefaultTableModel;

public class UnDo {

	Connection connect = null;
	//public static void unDo(Connection connect, String[] undoArray) {
	public void unDo(Connection connect, Object[] undoData) {
	
		DeleteRow delRow = new DeleteRow();
		//translation from object arrary to string arrayL list
		//String[] stringArray = Arrays.copyOf(undoData, undoData.length, String[].class);
		//trabslation from object array  to String array
		//Object[] undoData = new String[12];
		//String[] s = (String[]) undoData;
		
				// delete original records from query to give room for updated one
		try {		
				String valueT1 = String.valueOf(undoData[0]);
				String valueT2 = String.valueOf(undoData[1]);
				String valueT3 = String.valueOf(undoData[2]);
				String valueT4 = String.valueOf(undoData[3]);
				String valueT5 = String.valueOf(undoData[4]);
				String valueT6 = String.valueOf(undoData[5]);
				String valueT7 = String.valueOf(undoData[6]);
				String valueT8 = String.valueOf(undoData[7]);
				String valueT9 = String.valueOf(undoData[8]);
				String valueT10 = String.valueOf(undoData[9]);
				String valueT11 = String.valueOf(undoData[10]);
				String valueT12 = String.valueOf(undoData[11]);
				
				if(valueT1.equals("null")){
					JOptionPane.showMessageDialog(null, "Nothing to Undo");
					return;
				}

				
				int firstCol = Integer.parseInt(valueT1);
				
				//delRow.deleteRow(firstCol,connect);
				
				int f1 =  Integer.parseInt(valueT1);
				int f5 =  Integer.parseInt(valueT5);
				int f6 =  Integer.parseInt(valueT6);
				int f9 =  Integer.parseInt(valueT9);
				
				String queryUpdate = "INSERT INTO Vehicles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

					PreparedStatement psUp = connect.prepareStatement(queryUpdate);
											    				    	
			    	psUp.setInt(1, f1);
			    	psUp.setString(2, valueT2);
			    	psUp.setString(3, valueT3);  	
					psUp.setString(4, valueT4.toUpperCase());
					psUp.setInt(5, f5);
					psUp.setInt(6, f6);
					psUp.setString(7, valueT7);
					psUp.setString(8, valueT8);
					psUp.setInt(9, f9);
					psUp.setString(10, valueT10.toUpperCase());
					
					if(!String.valueOf(undoData[10]).equals("null")) {
						psUp.setInt(11, Integer.parseInt(valueT11));
				    	}else {
				    		//psUp.setInt(11, 0);
				    		psUp.setNull(11, java.sql.Types.DOUBLE);
				    	}
				    if(!String.valueOf(undoData[11]).equals("null")) {
				    		psUp.setInt(12, Integer.parseInt(valueT12));
					    }else {
					    	psUp.setNull(12, java.sql.Types.DOUBLE);
					    	//psUp.setInt(12, 0);
					    }
				    
				    delRow.deleteRow(firstCol,connect);
			   psUp.executeUpdate();
			    	psUp.close();
			    	
			}catch(Exception e1) {
				JOptionPane.showMessageDialog(null, e1);
			}
				
	}
}