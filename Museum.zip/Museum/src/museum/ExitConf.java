package museum;

import java.awt.GridLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class ExitConf extends JPanel {

	/**
	 * Create the panel.
	 * @return 
	 */
	public void exitConf() {
		 JPanel panel = new JPanel(new GridLayout(0, 1));
		 JOptionPane.showConfirmDialog(null, panel, "Test", JOptionPane.OK_CANCEL_OPTION);
			UIManager.put("OptionPane.okButtonText", "OK");
	}

}
