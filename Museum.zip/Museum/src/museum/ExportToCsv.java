package museum;

import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ExportToCsv {
	private List<String> resultSetArray=new ArrayList<>();
	Connection connect = null;
	
	
	public void exportToCsv(Connection conn, String pathToSave) {
		try{
		String queryAll = "select * from Vehicles";
		Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(queryAll);
        int ColumnNo = rs.getMetaData().getColumnCount();
        
        while(rs.next()) {
            StringBuilder sb = new StringBuilder();

            for (int i = 1; i <= ColumnNo; i++) {
                sb.append(String.format(String.valueOf(rs.getString(i))) + " ");

            }
            resultSetArray.add(sb.toString());

        }

    
		String filename = pathToSave+".csv";
		//File csvOutputFile = new File("/home/ra/Documents/testsql.csv");
		File csvOutputFile = new File(filename);
        FileWriter fileWriter = new FileWriter(csvOutputFile, false);


        for(String mapping : resultSetArray) {
            fileWriter.write(mapping + "\n");
         }
        fileWriter.close();
		} catch(Exception e) {
	        System.out.println("Cos nie tak!");
	        }
       
		
}
	
	
}
		
	
	

