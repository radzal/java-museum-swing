package museum;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SelectedRow {
	/*
			Connection connect = null;
			//public static void unDo(Connection connect, String[] undoArray) {
			public void unDo(Connection connect, Object[] undoData) {
				//getting first cell
					String queryRow = "select vehicle_id from VEHICLES where Vehicle_id=?";
					PreparedStatement pst = connect.prepareStatement(queryRow);
					pst.setInt(1, f1);
					ResultSet rs = pst.executeQuery();
						while(rs.next()) {
							firstCol = rs.getString(1);
							String queryRow1 = "select * from VEHICLES where Vehicle_id = ?";
							
							
					PreparedStatement pst1 = connect.prepareStatement(queryRow1);
							pst1.setInt(1, f1);
							ResultSet rs1 = pst1.executeQuery();
						while(rs1.next()) {
		
							for (int i = 0; i < 12; i++)
							{
								undoData[i] = rs1.getString(i+1);
							}								

	}
}
*/
}