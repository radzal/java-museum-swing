package museum;

import java.awt.GridLayout;
import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.sql.ResultSet;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
//import javax.swing.JPasswordField;
import javax.swing.JTextField;
//import javax.swing.UIManager;

public class AddBike {

	Connection connect = null;
	JTextField textField;
	

	@SuppressWarnings("rawtypes")
	public void addBike(Connection Into) {
		String[] optionsType = { "Caferacer", "Cruiser", "Scooter", "Sport", "Trials", "Tourer", "Other" };

		GetLastId lastId = new GetLastId();

			//String query = "insert into VEHICLES(vehicle_id, veh_type, veh_model, plate, dateProd, valuev, colour, fuel, cc, typeB, doorc, seatsc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			String query = "INSERT INTO Vehicles VALUES(?,?,?,?,?,?,?,?,?,?,null,null)";
							
						try {
							//System.out.println(input1);
							//String query = queryIn;
							JPanel panel = new JPanel(new GridLayout(0, 1));
							int lastIdVal = (Integer.parseInt(lastId.getLastId(Into))+1);
							
							//Value in fiels1 converted to String
							JTextField field1 = new JTextField(String.valueOf(lastIdVal));
					        //JTextField field2 = new JTextField("bike");
					        JTextField field3 = new JTextField();
					        JTextField field4 = new JTextField();
							JTextField field5 = new JTextField();
					        JTextField field6 = new JTextField();
					        JTextField field7 = new JTextField();
					        //JTextField field8 = new JTextField("p");
							JTextField field9 = new JTextField();
					        //JTextField field10 = new JTextField();
					        //JTextField field11 = new JTextField();
					        //JTextField field12 = new JTextField();
					     
					        @SuppressWarnings("unchecked")
							JComboBox optionListType = new JComboBox(optionsType);
					        optionListType.setSelectedIndex(1);
					        
					        panel.add(new JLabel("Vehicle Id"));
					        panel.add(field1);
					        //panel.add(new JLabel("Type"));
					        //panel.add(field2);
					        panel.add(new JLabel("Model"));
					        panel.add(field3);
					        panel.add(new JLabel("Reg Plates"));
					        panel.add(field4);
					        panel.add(new JLabel("Production Year"));
					        panel.add(field5);
					        panel.add(new JLabel("Value"));
					        panel.add(field6);
					        panel.add(new JLabel("Colour"));
					        panel.add(field7);
					     // panel.add(new JLabel("Fuel"));
					     // panel.add(optionListFuel);
					     // panel.add(field8);
					        panel.add(new JLabel("Engine"));
					        panel.add(field9);
					     // panel.add(new JLabel("Bike type"));
					     // panel.add(field10);
					        panel.add(new JLabel("Bike type"));
					        panel.add(optionListType);
					        //panel.add(new JLabel("Doors no"));
					        //panel.add(field11);
					        //panel.add(new JLabel("Seats No"));
					        //panel.add(field12);
					        
					    	JOptionPane.showConfirmDialog(null, panel, "- Add Bike -", JOptionPane.OK_CANCEL_OPTION);					        
					       
					    	PreparedStatement pst = Into.prepareStatement(query);
							
							int f1 =  Integer.parseInt(field1.getText());

							int f5 =  Integer.parseInt(field5.getText());
							int f6 =  Integer.parseInt(field6.getText());

							int f9 =  Integer.parseInt(field9.getText());
							
							String vehType = String.valueOf(optionListType.getSelectedItem());

							pst.setInt(1, f1);
							pst.setString(2, "bike");
							pst.setString(3, field3.getText());
							pst.setString(4, field4.getText().toUpperCase());
							pst.setInt(5, f5);
							pst.setInt(6, f6);
							pst.setString(7, field7.getText());
							pst.setString(8, "petrol");
							pst.setInt(9, f9);
							//pst.setString(10, field10.getText().toUpperCase());
							pst.setString(10, vehType);
							//pst.setInt(11, f11);
							//pst.setInt(12, f12); 
			
							pst.executeUpdate();
							
							pst.close();
							
						}catch(Exception e) {
							//JOptionPane.showMessageDialog(null, "Cannceled by user");
						
						}
						return;
				//return connect;
			}
}