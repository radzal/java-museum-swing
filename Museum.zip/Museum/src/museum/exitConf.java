package museum;

import javax.swing.JPanel;

public class exitConf extends JPanel {

	/**
	 * Create the panel.
	 */
	public exitConf() {

	}

}
