package museum;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class SearchStr {
	Connection connect = null;

	public void searchString(DefaultTableModel model, Connection connect, String input) {
		try {
			String input1 = input.toUpperCase();
			//String query = "select * from Vehicles order by Vehicle_ID";
			//String query = "select * from VEHICLES where * like=?";
			String query = "select * from VEHICLES where upper(veh_model) like ? or plate like ? or dateprod like ? or valuev like ? or upper(colour) like ? or upper(fuel) like ? or cc like ? or upper(typeB) like ? or doorC like ? or seatsC like ?";
			PreparedStatement pst = connect.prepareStatement(query);
			pst.setString(1, "%"+input1+"%");
			pst.setString(2, "%"+input1+"%");
			pst.setString(3, "%"+input1+"%");
			pst.setString(4, "%"+input1+"%");
			pst.setString(5, "%"+input1+"%");
			pst.setString(6, "%"+input1+"%");
			pst.setString(7, "%"+input1+"%");
			pst.setString(8, "%"+input1+"%");
			pst.setString(9, "%"+input1+"%");
			pst.setString(10, "%"+input1+"%");
			
			
			ResultSet rs = pst.executeQuery();
			ResultSetMetaData meta = rs.getMetaData();
			int numberOfColumns = meta.getColumnCount();
			int count = 0;
			model.setRowCount(0);
			while(rs.next()) {
				
				Object [] rowData = new Object[numberOfColumns];
                for (int i = 0; i < rowData.length; ++i)
                {
                    rowData[i] = rs.getObject(i+1);
                    
                    if(rowData[i] == null) {
                    	rowData[i] = "n/a";
                    }else if(rowData[i].equals("p")) {
                    	rowData[i] = "petrol";
                    }else if(rowData[i].equals("d")) {
                    	rowData[i] = "diesel";
                    }
                }
                model.addRow(rowData);
				count++;
							}

			model.fireTableDataChanged();
			rs.close();
			pst.close();
		}catch(Exception e1) {
			//JOptionPane.showMessageDialog(null, "zzzzzConnection not established.\nCheck credentials\nGo to menu and try again.");
			return;
		}
	}
}
