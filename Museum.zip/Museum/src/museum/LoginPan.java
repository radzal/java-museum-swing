package museum;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;

import java.sql.Connection;

import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginPan extends JPanel {
	private JTextField textField;
	private JPasswordField passwordField;
	
	Connection connection = null;
	/**
	 * Create the panel.
	 */
	public LoginPan() {/*
		setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(99, 26, 114, 21);
		add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(99, 59, 114, 21);
		add(passwordField);
		
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(22, 27, 69, 17);
		add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(22, 60, 63, 17);
		add(lblPassword);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				connection = SQLconnect.dbConnector(textField.getText(), passwordField.getText());

			}
		});
		btnNewButton.setBounds(99, 101, 114, 27);
		add(btnNewButton);
		*/
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.setBounds(258, 101, 72, 27);
		add(btnNewButton_1);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(236, 26, 10, 102);
		add(separator);

	}
}
