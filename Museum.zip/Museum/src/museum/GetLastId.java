package museum;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class GetLastId {
	
	//Must be added
	Connection connect = null;
	
	//Parameter from calling method with valid Connection needs to be added
	public String getLastId(Connection Into) {
		Statement stmt = null;
		String rsOut = null;
		String query = "select max(vehicle_id)from VEHICLES";
			try {
				stmt = Into.createStatement();

				ResultSet rs = stmt.executeQuery(query);
				
				//This is returning one value
				while(rs.next()) {
				
				rsOut = rs.getString(1);

				System.out.println(rsOut);
				}
				

				stmt.close();

			}catch(SQLException e) {
				JOptionPane.showMessageDialog(null, e);
			}

			return rsOut;
	}

}