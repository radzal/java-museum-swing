package museum;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;

public class DeleteRow {
	Connection connect = null;
	
	
	public void deleteRow(int input1, Connection Into) {

	String query = "delete from VEHICLES where vehicle_id = ?";
					
				try {

					PreparedStatement pst = Into.prepareStatement(query);
					pst.setInt(1, input1);

					pst.executeUpdate();

					pst.close();

				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
}