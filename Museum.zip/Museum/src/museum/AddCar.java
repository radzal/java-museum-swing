package museum;

import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddCar {

	Connection connect = null;
	JTextField textField;
	

	public String addCar(Connection Into) {
		
		GetLastId lastId = new GetLastId();
		String query = null;
		String[] optionsFuel = { "Diesel", "Electric", "Petrol", "Other" };					
						try {
							JPanel panel = new JPanel(new GridLayout(0, 1));
							int lastIdVal = (Integer.parseInt(lastId.getLastId(Into))+1);

							
							//Value in fiels1 converted to String
							JTextField field1 = new JTextField(String.valueOf(lastIdVal));
					        //	JTextField field2 = new JTextField("car");
					        JTextField field3 = new JTextField();
					        JTextField field4 = new JTextField();
							JTextField field5 = new JTextField();
					        JTextField field6 = new JTextField();
					        JTextField field7 = new JTextField();
					        JTextField field8 = new JTextField();
							JTextField field9 = new JTextField();
							//     JTextField field10 = new JTextField();
					        JTextField field11 = new JTextField();
					        JTextField field12 = new JTextField();
					        JComboBox optionListFuel= new JComboBox(optionsFuel);
					     	optionListFuel.setSelectedIndex(3);

					        
					        panel.add(new JLabel("Vehicle Id"));
					        panel.add(field1);
					     //	panel.add(new JLabel("Type"));
					     // panel.add(field2);
					        panel.add(new JLabel("Model"));
					        panel.add(field3);
					        panel.add(new JLabel("Reg Plates"));
					        panel.add(field4);
					        panel.add(new JLabel("Production Year"));
					        panel.add(field5);
					        panel.add(new JLabel("Value"));
					        panel.add(field6);
					        panel.add(new JLabel("Colour"));
					        panel.add(field7);
					        panel.add(new JLabel("Fuel"));
					        panel.add(optionListFuel);
					        //panel.add(field8);
					        panel.add(new JLabel("Engine"));
					        panel.add(field9);
					//        panel.add(new JLabel("Bike type"));
					//        panel.add(field10);
					        panel.add(new JLabel("Doors no"));
					        panel.add(field11);
					        panel.add(new JLabel("Seats No"));
					        panel.add(field12);
					        
					    	JOptionPane.showConfirmDialog(null, panel, "- Add Car -", JOptionPane.OK_CANCEL_OPTION);					        
					      // if(field1.getText() == null ||field3.getText() == null ||field4.getText() == null||field5.getText()||field6.getText()||field7.getText()||field9.getText()||field11.getText()||field12.getText() == null)
					    	String vehFuel = String.valueOf(optionListFuel.getSelectedItem());
					    	
							query = "INSERT INTO Vehicles VALUES("+field1.getText()+",'"+"car"+"','"+field3.getText()+"','"+field4.getText().toUpperCase()+"',"+field5.getText()+
									","+field6.getText()+",'"+field7.getText()+"','"+vehFuel+"',"+field9.getText()+","+null+","+field11.getText()+","+field12.getText()+")";
							//addRecord.addRecord(Into, query);
							try {
						    	PreparedStatement pst = Into.prepareStatement(query);
								pst.executeUpdate(query);
								pst.close();
							}catch(Exception e) {
								JOptionPane.showMessageDialog(null, "You did't input enought information" );
							}
						}catch(Exception e) {
							//JOptionPane.showMessageDialog(null, e);
						}
				//return addCarArr;
				return query;
			}
}
