package museum;
import java.sql.*;
import javax.swing.*;

public class ConnectToDB {
	
	Connection conn = null;
	private static String usr;
	private static String ip;
	public static Connection dbConnector(String usr, String pass, String ip, String port, String sid) {
	//public static Connection dbConnector(String usr, String pass) {
		ConnectToDB.usr = usr;
		ConnectToDB.ip = ip;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"+usr+"/"+pass+"@192.168.0.10:1521:xe");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"+usr+"/"+pass+"@"+ip+":"+port+":"+sid);
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"+usrIn+"/"+passIn+"@"+ipIn+":"+portIn+":"+"xe");
			//Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"+usrIn+"/"+passIn+"@"+"192.168.0.10"+":1521:xe");
			JOptionPane.showMessageDialog(null, "Connection Successful");
			return conn;
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Connection not established.\nCheck credentials\nGo to menu and try again.");
			return null;
		}
		//return ipB;
	}
	
	public String usrAndIpReturn(){
	
		String ipB = " User: "+usr+"   |   Server: "+ip+"   |   ";
		return ipB;
	}
	
}
