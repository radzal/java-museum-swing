package museum;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;


public class SelectMore {
	
	Connection connect = null;
	
	

ResultSet selectMore(String queryIn, String input1, Connection Into) {
	ResultSet rsOut = null;
	
	//LoginDialog dlg = new LoginDialog();
	//connect = dlg.loginDialog();
	//Connection connect = null;
				
			try {
				//System.out.println(input1);
				//String query = "select student_id from student where first_name = ?";
				String query = queryIn;
				PreparedStatement pst = Into.prepareStatement(query);
				pst.setString(1, input1);
				ResultSet rs = pst.executeQuery();
				int count = 0;
				while(rs.next()) {
					count++;
				}
				if (count == 1) {
					JOptionPane.showMessageDialog(null, "Username exists in DB");
					
				}else if(count > 1){
					JOptionPane.showMessageDialog(null, "Duplicate record for This User");
				}else {
					JOptionPane.showMessageDialog(null, "Record does not exixt");
				}
				rsOut = rs;
				rs.close();
				pst.close();
				
				
				System.out.println(rs);
				System.out.println(pst);
			}catch(Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}
			return rsOut;
			
		}
	
	
	
 }
